#!/usr/bin/env python3
"""Narrow parent-authorized footer repair; retained v1 is read-only."""
import copy
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / '.local/stage-one'
DEST = ROOT / '.local/stage-one-v2'
APPROVAL = ROOT / 'footer-repair-approval.json'
APPROVAL_SHA = '24533c60c5097b9e005660bc64f220ad0d35c02ca4cdc4b4bbfeef8a6a999bbc'
ARCHIVE = ROOT / '.local/footer-repair-source-archive/generate-first-realization.py'
ORIGINAL_CODE_SHA = '4ff173f892f6fe177f2e643228b11f0a06ffae267ec81baef726823dd20dd656'
OLD = {
    38871: 'This is a fictional physical-observation collection, not simulated measurements or a claim about real data.',
    38872: 'All described observations are fictional physical events within this fixture, not simulations or real-world data claims.',
    38873: 'The collection depicts fictional physical observations; it makes no claim to hold real data or simulated results.'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fsha(path):
    return sha(path.read_bytes())


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()


def pretty(obj):
    return json.dumps(obj, sort_keys=True, indent=2, ensure_ascii=False).encode() + b'\n'


def differences(a, b, pointer=''):
    if type(a) is not type(b):
        return [pointer]
    if isinstance(a, dict):
        if a.keys() != b.keys():
            return [pointer + '/<keys>']
        return [p for k in a for p in differences(a[k], b[k], pointer + '/' + k)]
    if isinstance(a, list):
        if len(a) != len(b):
            return [pointer + '/<length>']
        return [p for i, (x, y) in enumerate(zip(a, b)) for p in differences(x, y, pointer + '/' + str(i))]
    return [] if a == b else [pointer]


def repaired_record(before, seed, new, project):
    after = copy.deepcopy(before)
    old = OLD[seed]
    fields = []
    if old in before['description']:
        assert before['description'].endswith(old)
        assert before['description'].count(old) == 1
        after['description'] = before['description'][:-len(old)] + new
        del after['queryContext']
        after['queryContext'] = project(after)
        assert differences(before, after) == ['/description', '/queryContext']
        assert len(old.split()) == len(new.split())
        assert len(before['description'].split()) == len(after['description'].split())
        assert before['description'][:-len(old)] == after['description'][:-len(new)]
        fields = [{'json_pointer': '/' + field, 'before': before[field], 'after': after[field],
                   'before_utf8_sha256': sha(before[field].encode()), 'after_utf8_sha256': sha(after[field].encode())}
                  for field in ('description', 'queryContext')]
    else:
        assert before == after
    return after, fields


def run():
    assert fsha(APPROVAL) == APPROVAL_SHA
    approval = json.loads(APPROVAL.read_text())
    assert fsha(ROOT / approval['finding_path']) == approval['finding_sha256']
    assert fsha(SOURCE / 'manifest.json') == approval['source_manifest_sha256']
    original_manifest_bytes = (SOURCE / 'manifest.json').read_bytes()
    original = json.loads(original_manifest_bytes)
    assert fsha(ARCHIVE) == ORIGINAL_CODE_SHA
    assert fsha(ROOT / 'spec-freeze.json') == approval['spec_freeze_sha256']
    # Source history proof: replacing only three exact string literals yields
    # the complete current source, with every other byte identical.
    previous_source = ARCHIVE.read_bytes()
    expected_source = previous_source
    for seed in (38871, 38872, 38873):
        old, new = OLD[seed], approval['new_footers'][str(seed)]
        assert expected_source.count(old.encode()) == 1
        assert len(old.split()) == len(new.split())
        expected_source = expected_source.replace(old.encode(), new.encode(), 1)
    assert (ROOT / 'generate.py').read_bytes() == expected_source
    spec = importlib.util.spec_from_file_location('narrow_footer_generator', ROOT / 'generate.py')
    g = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(g)
    g.freeze.verify(ROOT)
    architecture = json.loads((ROOT / 'generation-spec.json').read_text())
    for seed, actual_footer in zip(g.SEEDS, g.FICTION):
        assert actual_footer == approval['new_footers'][str(seed)]
    new_core, new_growth, new_terminals = g.realize(architecture)
    generated = g.artifact_bytes(new_core, new_growth, new_terminals)
    source_hashes = {}
    for name, expected in original['artifact_sha256'].items():
        assert fsha(SOURCE / name) == expected
        source_hashes[name] = expected
    records = []
    changed, unchanged = 0, 0
    for seed in g.SEEDS:
        seed_changed, seed_unchanged = 0, 0
        for kind in ('core', 'growth'):
            name = f'{kind}-{seed}.jsonl'
            old_lines = (SOURCE / name).read_bytes().splitlines(keepends=True)
            new_lines = generated[name].splitlines(keepends=True)
            assert len(old_lines) == len(new_lines) == (60 if kind == 'core' else 20)
            for number, (old_line, new_line) in enumerate(zip(old_lines, new_lines), 1):
                assert old_line.endswith(b'\n') and new_line.endswith(b'\n')
                before, actual = json.loads(old_line), json.loads(new_line)
                assert sha(old_line) == original['raw_record_sha256'][str(seed)][before['identifier']]
                assert sha(canonical(before)) == original['canonical_record_sha256'][str(seed)][before['identifier']]
                after, fields = repaired_record(before, seed, approval['new_footers'][str(seed)], g.context)
                assert actual == after
                assert new_line == canonical(after) + b'\n'
                if fields:
                    changed += 1
                    seed_changed += 1
                else:
                    unchanged += 1
                    seed_unchanged += 1
                    assert new_line == old_line
                records.append({'seed': seed, 'identifier': before['identifier'],
                                'source_path': '.local/stage-one/' + name, 'source_line': number,
                                'new_path': '.local/stage-one-v2/' + name,
                                'before_raw_record_sha256': sha(old_line), 'after_raw_record_sha256': sha(new_line),
                                'before_canonical_record_sha256': sha(canonical(before)),
                                'after_canonical_record_sha256': sha(canonical(after)),
                                'description_word_count_before': len(before['description'].split()),
                                'description_word_count_after': len(after['description'].split()),
                                'changed_fields': fields, 'all_other_fields_identical': True})
        assert (seed_changed, seed_unchanged) == (68, 12)
    assert (changed, unchanged) == (204, 36)
    original_terminals = json.loads((SOURCE / 'terminal-templates.json').read_text())
    expected_terminals = copy.deepcopy(original_terminals)
    terminal_deltas = []
    assert len(original_terminals['bundles']) == 60
    for index, bundle in enumerate(expected_terminals['bundles']):
        original_bundle = original_terminals['bundles'][index]
        before = original_bundle['metadata']
        after, fields = repaired_record(before, bundle['seed'], approval['new_footers'][str(bundle['seed'])], g.context)
        assert len(fields) == 2
        bundle['metadata'] = after
        assert differences(original_bundle, bundle) == ['/metadata/description', '/metadata/queryContext']
        assert bundle['slot_bindings'] == original_bundle['slot_bindings']
        terminal_deltas.append({'bundle_index': index, 'seed': bundle['seed'], 'archetype_id': bundle['archetype_id'],
                                'before_canonical_bundle_sha256': sha(canonical(original_bundle)),
                                'after_canonical_bundle_sha256': sha(canonical(bundle)),
                                'changed_fields': [{**field, 'json_pointer': '/metadata' + field['json_pointer']} for field in fields],
                                'all_other_fields_and_slots_identical': True})
    assert expected_terminals == new_terminals
    assert generated['terminal-templates.json'] == pretty(expected_terminals)
    for b in new_terminals['bundles']:
        index = int(b['archetype_id'][1:]) - 1
        assert g.render_representative(b) == new_growth[b['seed']][index]
    old_snapshot = {name: (SOURCE / name).read_bytes() for name in original['artifact_sha256']}
    old_snapshot['manifest.json'] = original_manifest_bytes
    report = {'schema_version': 1, 'repair_id': 'C-actual-basis-footer', 'stage': 'stage_one_v2_footer_only_delta',
              'approval': {'path': 'footer-repair-approval.json', 'sha256': APPROVAL_SHA},
              'finding': {'path': approval['finding_path'], 'sha256': approval['finding_sha256']},
              'source_manifest': {'path': '.local/stage-one/manifest.json', 'sha256': approval['source_manifest_sha256']},
              'source_history': {'archived_path': str(ARCHIVE.relative_to(ROOT)), 'old_sha256': ORIGINAL_CODE_SHA,
                                 'new_sha256': fsha(ROOT / 'generate.py'), 'complete_source_diff_exactly_three_approved_string_literals': True},
              'allowed_changed_field_paths': ['/description', '/queryContext'],
              'old_footers': {str(k): v for k, v in OLD.items()}, 'approved_new_footers': approval['new_footers'],
              'record_count': len(records), 'changed_record_count': changed, 'unchanged_record_count': unchanged,
              'terminal_count': 60, 'changed_terminal_count': 60,
              'every_changed_description_exact_suffix_replacement': True,
              'every_root_context_exactly_production_derived': True,
              'all_description_word_counts_preserved': True, 'all_frozen_budgets_pass': True,
              'all_canonical_body_and_other_metadata_and_slot_fields_identical': True,
              'frozen_architecture_unchanged': True, 'no_simulation_only_contradiction_inferred': True,
              'independent_validation_claimed': False, 'full_fresh_240_record_audit_required': True,
              'new_artifact_sha256': {name: sha(data) for name, data in generated.items()},
              'original_artifact_sha256': source_hashes, 'records': records, 'terminal_bundles': terminal_deltas}
    report_bytes = pretty(report)
    all_files = dict(generated)
    all_files['footer-delta-report.json'] = report_bytes
    if DEST.exists():
        # Strict idempotence only; no overwrite of partial/rejected realizations.
        manifest = json.loads((DEST / 'manifest.json').read_text())
        for name, data in all_files.items():
            assert (DEST / name).read_bytes() == data, 'Retain mismatched output: ' + name
        assert manifest['repair']['delta_report']['sha256'] == sha(report_bytes)
        assert manifest['source_sha256'] == g.source_hashes()
        assert manifest['repair']['orchestrator_sha256'] == fsha(Path(__file__))
        g.verify_existing(DEST, generated, g.freeze.verify(ROOT))
    else:
        manifest = copy.deepcopy(original)
        manifest['artifact_version'] = 2
        manifest['created_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        manifest['source_sha256'] = g.source_hashes()
        manifest['artifact_sha256'] = {name: sha(data) for name, data in generated.items()}
        for entry in manifest['corpora'] + manifest['templates']:
            name = Path(entry['path']).name
            entry['path'] = '.local/stage-one-v2/' + name
            entry['sha256'] = sha(generated[name])
        manifest['terminal_templates']['path'] = '.local/stage-one-v2/terminal-templates.json'
        manifest['terminal_templates']['sha256'] = sha(generated['terminal-templates.json'])
        for seed in g.SEEDS:
            raw, normalized = {}, {}
            for kind in ('core', 'growth'):
                for line in generated[f'{kind}-{seed}.jsonl'].splitlines(keepends=True):
                    record = json.loads(line)
                    raw[record['identifier']] = sha(line)
                    normalized[record['identifier']] = sha(canonical(record))
            manifest['raw_record_sha256'][str(seed)] = raw
            manifest['canonical_record_sha256'][str(seed)] = normalized
        manifest['repair'] = {'id': 'C-actual-basis-footer', 'approval_path': 'footer-repair-approval.json',
                              'approval_sha256': APPROVAL_SHA, 'finding_path': approval['finding_path'],
                              'finding_sha256': approval['finding_sha256'],
                              'original_manifest_path': '.local/stage-one/manifest.json',
                              'original_manifest_sha256': approval['source_manifest_sha256'],
                              'original_terminal_sha256': approval['source_terminals_sha256'],
                              'delta_report': {'path': '.local/stage-one-v2/footer-delta-report.json', 'sha256': sha(report_bytes)},
                              'orchestrator_path': str(Path(__file__).relative_to(ROOT)), 'orchestrator_sha256': fsha(Path(__file__)),
                              'archived_source_path': str(ARCHIVE.relative_to(ROOT)), 'archived_source_sha256': ORIGINAL_CODE_SHA,
                              'changed_record_count': 204, 'unchanged_record_count': 36,
                              'fresh_independent_actual_text_audit_required': True, 'expansion_allowed': False,
                              'embeddings_search_native_comparisons_allowed': False}
        assert manifest['actual_text_validation_passed'] is False
        DEST.mkdir()
        for name, data in all_files.items():
            with (DEST / name).open('xb') as stream:
                stream.write(data)
        with (DEST / 'manifest.json').open('xb') as stream:
            stream.write(pretty(manifest))
        g.verify_existing(DEST, generated, g.freeze.verify(ROOT))
    for name, data in old_snapshot.items():
        assert (SOURCE / name).read_bytes() == data
    assert fsha(ARCHIVE) == ORIGINAL_CODE_SHA
    g.freeze.verify(ROOT)
    print(json.dumps({'stage': 'stage_one_v2', 'manifest_sha256': fsha(DEST / 'manifest.json'),
                      'terminal_sha256': fsha(DEST / 'terminal-templates.json'),
                      'delta_report_sha256': fsha(DEST / 'footer-delta-report.json'),
                      'changed_records': changed, 'unchanged_records': unchanged, 'changed_terminals': 60,
                      'originals_unchanged': True, 'full_audit_required': True}, sort_keys=True))


if __name__ == '__main__':
    run()
